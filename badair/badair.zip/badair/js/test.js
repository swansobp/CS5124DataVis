d3.csv('data/airdataHamilton.csv')
  .then(data => {
  	console.log('Data loading complete. Work with dataset.');
      console.log(data);

    //process the data - this is a forEach function.  You could also do a regular for loop.... 
    data.forEach(d => { //ARROW function - for each object in the array, pass it as a parameter to this function
        d.year = +d.year;
        d.maxAQI = +d.maxAQI;
        d._90percentileAQI = +d._90percentileAQI;
        d.medianAQI = +d.medianAQI;
      	// d.daysFromYrStart = computeDays(d.start); //note- I just created this field in each object in the array on the fly

				// let tokens = d.start.split("-");
  			// d.year = +tokens[0];

  	});
	  console.log(data);
});