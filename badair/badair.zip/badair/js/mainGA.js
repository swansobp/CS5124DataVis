d3.csv('data/airdataHamilton3.csv')
  .then((data) => {
    data.forEach((d) => {
        d.year = +d.year;
        d.maxAQI = +d.maxAQI;
        d.ninetyAQI = +d.ninetyAQI;
        d.medianAQI = +d.medianAQI;

        d.daysCO = +d.daysCO;
        d.daysNO2 = +d.daysNO2;
        d.daysOzone = +d.daysOzone;
        d.daysSO2 = +d.daysSO2;
        d.daysPM2point5 = +d.daysPM2point5;
        d.daysPM10 = +d.daysPM10;

        d.daysWithoutMeasurement = +d.daysWithoutMeasurement;
        d.daysWithAQI = +d.daysWithAQI;

        d.percentageAQI = [
          percentageCalc(d.goodDays, d.daysWithAQI),
          percentageCalc(d.moderateDays, d.daysWithAQI),
          percentageCalc(d.unhealthyForSensitiveGroupsDays, d.daysWithAQI),
          percentageCalc(d.unhealthyDays, d.daysWithAQI),
          percentageCalc(d.veryUnhealthyDays, d.daysWithAQI),
          percentageCalc(d.hazardousDays, d.daysWithAQI),
        ];

        d.percentagePollutants = [
          percentageCalc(d.daysCO, d.daysWithAQI),
          percentageCalc(d.daysNO2, d.daysWithAQI),
          percentageCalc(d.daysOzone, d.daysWithAQI),
          percentageCalc(d.daysSO2, d.daysWithAQI),
          percentageCalc(d.daysPM2point5, d.daysWithAQI),
          percentageCalc(d.daysPM10, d.daysWithAQI),
        ];

        if (isLeapYear(d.year)) {
          d.daysWithoutMeasurement = (366 - d.daysWithAQI);
        } else {
          d.daysWithoutMeasurement = (365 - d.daysWithAQI);
        };
  	});

    dataGroupYear = d3.group(
      data, d=>d.year
    )

    dataGroupCounty = d3.group(
      data, d => d.state, d => d.county
    );

    let dataGroupCounty2021 = d3.group(
      data, d => d.state, d => d.county, d => d.year
    );
    
    

		const lineChartAQI = new LineChart({
			'parentElement': '#aqiGA',
			'containerHeight': 500,
			'containerWidth': 800,
      'axisTitle': 'AQI'
		}, dataGroupCounty.get('Georgia').get('Washington'), ['maxAQI', 'medianAQI', 'ninetyAQI']);
    lineChartAQI.updateVis();

    const lineChartPollutants = new LineChart({
			'parentElement': '#pollutantsGA',
			'containerHeight': 500,
			'containerWidth': 800,
      'axisTitle': 'Pollutants'
		}, dataGroupCounty.get('Georgia').get('Washington'), ['daysCO', 'daysNO2', 'daysOzone', 'daysSO2', 'daysPM2point5', 'daysPM10']);
    lineChartPollutants.updateVis();
    
    const lineChartNoMeasurement = new LineChart({
			'parentElement': '#noMeasurementGA',
			'containerHeight': 500,
			'containerWidth': 800,
      'axisTitle': 'Days w/o measurement'
		}, dataGroupCounty.get('Georgia').get('Washington'), ['daysWithoutMeasurement']);
    lineChartNoMeasurement.updateVis();

    const barChartAirQuality = new BarChart({
      'parentElement': '#airQualityGA',
      'containerHeight': 500,
			'containerWidth': 1100,
    }, dataGroupCounty2021.get('Georgia').get('Washington').get(2021),
    ['Good Days', 'Moderate Days', 'Unhealthy for Sensitive Groups', 'Unhealthy Days', 'Very Unhealthy Days', 'Hazardous Days' ],
    'percentageAQI')
    barChartAirQuality.updateVis();
  
    const barChartPollutants = new BarChart({
      'parentElement': '#mainPollutantGA',
      'containerHeight': 500,
			'containerWidth': 1100,
    }, dataGroupCounty2021.get('Georgia').get('Washington').get(2021),
    ['CO', 'NO2', 'Ozone', 'SO2', 'PM 2.5', 'PM 10'],
    'percentagePollutants')
    barChartPollutants.updateVis();
})

.catch(error => {
    console.error(error);
});

function isLeapYear(year) {
  if (year % 400 === 0) return true;
  if (year % 100 === 0) return false;
  return year % 4 === 0;
}

function percentageCalc(column, daysWithAQI) {
  return (column / daysWithAQI);
}