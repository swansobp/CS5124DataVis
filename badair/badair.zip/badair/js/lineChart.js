class LineChart {

    /**
     * Class constructor with basic chart configuration
     * @param {Object}
     * @param {Array}
     */
    constructor(_config, _data, _columns) {
      this.config = {
        parentElement: _config.parentElement,
        containerWidth: _config.containerWidth || 800,
        containerHeight: _config.containerHeight || 240,
        axisTitle: _config.axisTitle || 'Axis',
        margin: _config.margin || {top: 25, right: 30, bottom: 30, left: 50}
      }
      this.data = _data;
      this.columns = _columns;
      this.initVis();
    }
    
    /**
     * Initialize scales/axes and append static chart elements
     */
     initVis() {
        let vis = this;
        vis.xValue = d => d.year;
        vis.yValue = d => d.maxAQI;
        vis.width = vis.config.containerWidth - vis.config.margin.left - vis.config.margin.right;
        vis.height = vis.config.containerHeight - vis.config.margin.top - vis.config.margin.bottom;
        vis.axisTitle = vis.config.axisTitle;

        vis.xScale = d3.scaleLinear()
            .domain(d3.extent(vis.data, vis.xValue))
            .range([0, vis.width]);
        vis.yScale = d3.scaleLinear()
            .domain([0,330])
            .range([vis.height, 0])
            .nice();

        vis.xAxis = d3.axisBottom(vis.xScale)
            .ticks(10)
            .tickSizeOuter(0)
            .tickPadding(10)
            .tickFormat(d3.format('d'));

        vis.yAxis = d3.axisLeft(vis.yScale)
            .ticks(6)
            .tickSizeOuter(3)
            .tickPadding(10);

        vis.svg = d3.select(vis.config.parentElement)
            .attr('width', vis.config.containerWidth)
            .attr('height', vis.config.containerHeight);

        vis.chartContainer = vis.svg.append('g')
            .attr('transform', `translate(${vis.config.margin.left},${vis.config.margin.top})`);

        vis.chart = vis.chartContainer.append('g');

        vis.xAxisG = vis.chart.append('g')
            .attr('class', 'axis x-axis')
            .attr('transform', `translate(0,${vis.height})`);

        vis.yAxisG = vis.chart.append('g')
            .call(vis.yAxis)
            .attr('class', 'axis y-axis')

        vis.yAxisG
            .style('font-size', '1rem')
            .style('font-family', 'inherit')
            .style('color', '#ffffff')

        vis.axisTitle = vis.chartContainer.append('text')
            .attr('class', 'axis-label')
            .attr('y', -18)
            .attr('x', -25)
            .attr('dy', '0.35em')
            .text(vis.axisTitle);

      }
    
      updateVis() {
        let vis = this;
        
        vis.renderVis();
      }
    
      /**
       * Bind data to visual elements
       */
      renderVis() {
        let vis = this;
        const color = [
            '#754E24','#8B4800','#CD6A00','#DD984F','#ECC79D','#FCF5EC'];

        vis.columns.forEach((c, i) => {
            vis.chart.append('path')
            .data([vis.data])
            .attr('stroke', color[i])
            .attr('stroke-width', 2)
            .attr('fill', 'none')
            .attr('d', d3.line()
                .x(d => vis.xScale(vis.xValue(d)))
                .y(d => vis.yScale(d[c])));
        })

        vis.xAxisG.call(vis.xAxis);
        vis.yAxisG.call(vis.yAxis);
    }
}